package com.Sbe.beans;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Card {
	@Id
	@GeneratedValue
	private int id;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	private CardExpiry cardExpiry;
	public Card() {
		super();
	}
	private String holdername;
	private String cardType;
	private String cardBin;
	private String lastDigits;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public CardExpiry getCardExpiry() {
		return cardExpiry;
	}
	public void setCardExpiry(CardExpiry cardExpiry) {
		this.cardExpiry = cardExpiry;
	}
	public String getHoldername() {
		return holdername;
	}
	public void setHoldername(String holdername) {
		this.holdername = holdername;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getCardBin() {
		return cardBin;
	}
	public void setCardBin(String cardBin) {
		this.cardBin = cardBin;
	}
	public String getLastDigits() {
		return lastDigits;
	}
	public void setLastDigits(String lastDigits) {
		this.lastDigits = lastDigits;
	}
	@Override
	public String toString() {
		return "Card [id=" + id + ", cardExpiry=" + cardExpiry + ", holdername=" + holdername + ", cardType=" + cardType
				+ ", cardBin=" + cardBin + ", lastDigits=" + lastDigits + "]";
	}
	
	
	
}
