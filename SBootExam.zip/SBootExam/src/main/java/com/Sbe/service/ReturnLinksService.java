package com.Sbe.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Sbe.beans.ReturnLinks;
import com.Sbe.repository.ReturnLinksRepository;

@Service
public class ReturnLinksService {
	@Autowired
	ReturnLinksRepository retRepo;
	public ReturnLinks save(ReturnLinks retLink)
	{
		return retRepo.save(retLink);
	}
	public List<ReturnLinks> findAll()
	{
		Iterable data=retRepo.findAll();
		Iterator dataloop=data.iterator();
		List<ReturnLinks> newData=new ArrayList<ReturnLinks>();
		while(dataloop.hasNext())
		{
			newData.add((ReturnLinks)dataloop.next());
		}
		return newData;
	}
}
