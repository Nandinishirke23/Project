package com.SBexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SBexamApplication {

	public static void main(String[] args) {
		SpringApplication.run(SBexamApplication.class, args);
	}

}
