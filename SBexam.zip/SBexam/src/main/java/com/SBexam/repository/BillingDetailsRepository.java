package com.SBexam.repository;

import org.springframework.data.repository.CrudRepository;

import com.SBexam.beans.BillingDetails;

public interface BillingDetailsRepository extends CrudRepository <BillingDetails,String>{



}
