package com.SBexam.repository;

import org.springframework.data.repository.CrudRepository;

import com.SBexam.beans.Card;

public interface CardRepository extends CrudRepository<Card,String>{

}
