package com.SBexam.repository;

import org.springframework.data.repository.CrudRepository;

import com.SBexam.beans.ReturnLinks;

public interface ReturnLinksRepository extends CrudRepository<ReturnLinks,String>{

}
