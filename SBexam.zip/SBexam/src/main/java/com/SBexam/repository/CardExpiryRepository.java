package com.SBexam.repository;

import org.springframework.data.repository.CrudRepository;

import com.SBexam.beans.CardExpiry;

public interface CardExpiryRepository extends CrudRepository<CardExpiry,String>{

}
