package com.SBexam.repository;

import org.springframework.data.repository.CrudRepository;

import com.SBexam.beans.PaymentMethod;

public interface PaymentMethodRepository extends CrudRepository<PaymentMethod,String>{

}
