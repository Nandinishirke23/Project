package com.SBexam.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ReturnLinks {
	@Id
	private String rel;
	private String href;
	private String Method;
	public String getRel() {
		return rel;
	}
	public void setRel(String rel) {
		this.rel = rel;
	}
	public String getHref() {
		return href;
	}
	public void setHref(String href) {
		this.href = href;
	}
	public String getMethod() {
		return Method;
	}
	public void setMethod(String Method) {
		Method = Method;
	}
	@Override
	public String toString() {
		return "ReturnLinks [rel=" + rel + ", href=" + href + ", Method=" + Method + "]";
	}
	
	

}
