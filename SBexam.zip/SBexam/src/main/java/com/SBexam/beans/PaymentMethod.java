package com.SBexam.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import org.springframework.beans.factory.annotation.Autowired;

@Entity
public class PaymentMethod {
@Id

	private String id;
	private int amount;
	private String merchantRefNum;
	private String action;
	private String currencyCode;
	private String usage;
	private String status;
	private int timeToLiveSeconds;
	private String transcationType;
	private String paymentType;
	private String executionMode;
	private String customerIp;
	private String paymentHandleToken;
//	@Autowired
//	private BillingDetails billingDetails;
//	@Autowired
//	private Card card;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getMerchantRefNum() {
		return merchantRefNum;
	}
	public void setMerchantRefNum(String merchantRefNum) {
		this.merchantRefNum = merchantRefNum;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getUsage() {
		return usage;
	}
	public void setUsage(String usage) {
		this.usage = usage;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getTimeToLiveSeconds() {
		return timeToLiveSeconds;
	}
	public void setTimeToLiveSeconds(int timeToLiveSeconds) {
		this.timeToLiveSeconds = timeToLiveSeconds;
	}
	public String getTranscationType() {
		return transcationType;
	}
	public void setTranscationType(String transcationType) {
		this.transcationType = transcationType;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getExecutionMode() {
		return executionMode;
	}
	public void setExecutionMode(String executionMode) {
		this.executionMode = executionMode;
	}
	public String getCustomerIp() {
		return customerIp;
	}
	public void setCustomerIp(String customerIp) {
		this.customerIp = customerIp;
	}
	public String getPaymentHandleToken() {
		return paymentHandleToken;
	}
	public void setPaymentHandleToken(String paymentHandleToken) {
		this.paymentHandleToken = paymentHandleToken;
	}
//	public BillingDetails getBillingDetails() {
//		return billingDetails;
//	}
//	public void setBillingDetails(BillingDetails billingDetails) {
//		this.billingDetails = billingDetails;
//	}
//	public Card getCard() {
//		return card;
//	}
//	public void setCard(Card card) {
//		this.card = card;
//	}
	@Override
	public String toString() {
		return "PaymentMethod [id=" + id + ", amount=" + amount + ", merchantRefNum=" + merchantRefNum + ", action="
				+ action + ", currencyCode=" + currencyCode + ", usage=" + usage + ", status=" + status
				+ ", timeToLiveSeconds=" + timeToLiveSeconds + ", transcationType=" + transcationType + ", paymentType="
				+ paymentType + ", executionMode=" + executionMode + ", customerIp=" + customerIp
				+ ", paymentHandleToken=" + paymentHandleToken + 
				"]";
	
	
	}

	
}
