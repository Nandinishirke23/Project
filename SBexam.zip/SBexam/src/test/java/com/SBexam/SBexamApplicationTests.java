package com.SBexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SBexamApplicationTests {

	@Test
	void contextLoads() {
	}

}
